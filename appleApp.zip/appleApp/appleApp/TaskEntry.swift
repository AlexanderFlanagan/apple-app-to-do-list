//
//  TaskEntry.swift
//  appleApp
//
//  Created by Clare Jones on 19/03/2020.
//  Copyright © 2020 Clare Jones. All rights reserved.
//

import UIKit

class TaskEntry:NSObject, NSCoding{
    func encode(with coder: NSCoder) {
        coder.encode(Title, forKey: PropertyKey.Title);
        coder.encode(DueDate, forKey: PropertyKey.DueDate);
        coder.encode(photo, forKey: PropertyKey.photo);
    }
    
    required convenience init?(coder: NSCoder) {
        //make sure we can decode the title, otherwise the initializer will fail
        guard let Title = coder.decodeObject(forKey: PropertyKey.Title)as? String else{
            print("Unable to decode the entry");
            return nil;
        }
        guard let DueDate = coder.decodeObject(forKey: PropertyKey.DueDate)as? String else{
            print("Unable to decode the entry");
            return nil;
        }
        
        let photo = coder.decodeObject(forKey: PropertyKey.photo) as? UIImage;
        
        self.init(Title:Title, DueDate:DueDate, photo:photo);
        
    }
    
    var Title: String
    var DueDate: String
    var photo:UIImage?
    
    init?(Title:String, DueDate:String, photo:UIImage?){
        // check for valid title and dude date, fail if not
        if(Title.isEmpty || DueDate.isEmpty){
            return nil;
        }
        self.Title = Title;
        self.DueDate = DueDate;
        self.photo = photo;
    }
    
    //make the data savable
    struct PropertyKey {
        static let Title = "Title";
        static let DueDate = "DueDate";
        static let photo = "photo";
        
    }
    static let DocumentDirectory = FileManager().urls(for:.documentDirectory, in:.userDomainMask).first!
    static let ArchiveURL = DocumentDirectory.appendingPathComponent("TaskEnteries");
}
