//
//  ViewController.swift
//  appleApp
//
//  Created by Clare Jones on 19/03/2020.
//  Copyright © 2020 Clare Jones. All rights reserved.
//

import UIKit

class TaskViewController: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate {

    @IBAction func cancel(_ sender: UIBarButtonItem) {
        let isPresentingInAddTaskMode = presentingViewController is UINavigationController
        if isPresentingInAddTaskMode{
            dismiss(animated: true, completion: nil);
        }else{
            if let owningNavigationController = navigationController{
                owningNavigationController.popViewController(animated: true)
            }
        }
        
        
    }
    @IBAction func selectImage(_ sender: Any) {
        //Hide Keyboard
        taskTitle.resignFirstResponder();
        
        //getb the image picker to select a phot from library
        let imagePickerController = UIImagePickerController();
        
        imagePickerController.sourceType = .photoLibrary
        
        imagePickerController.delegate = self;
        present(imagePickerController, animated: true, completion: nil);
    }
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        dismiss(animated: true, completion: nil);
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        // deal with multiple representations of the image
        guard let selectedImage = info[UIImagePickerController.InfoKey.originalImage] as? UIImage else{
            fatalError("Expected image and did not get one, got this instead\(info)");
        }
        //set view to display selected image
        taskImage.image = selectedImage;
        // dismiss picker
        dismiss(animated: true, completion: nil)
    }
    
    @IBOutlet weak var save: UIBarButtonItem!
    @IBOutlet weak var taskImage: UIImageView!
    @IBOutlet weak var taskTitle: UITextField!
    @IBOutlet weak var dueDate: UITextField!
    var task:TaskEntry?;
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        if let viewTask = task{
            taskTitle.text = viewTask.Title;
            dueDate.text = viewTask.DueDate;
            taskImage.image = viewTask.photo;
        }
    }
    
    override func prepare(for segue:UIStoryboardSegue, sender:Any?){
        super.prepare(for:segue, sender:sender);
        
        //check if the save button or cancel button is pressed
        guard let button = sender as? UIBarButtonItem, button===save else{
            return;
        }
        //save contact
        let Title = taskTitle.text ?? "";
        let DueDate = dueDate.text ?? "";
        let photo = taskImage.image;
        
        task  = TaskEntry(Title:Title, DueDate:DueDate, photo:photo);
        
    }


}

