//
//  TaskListViewControllerTableViewController.swift
//  appleApp
//
//  Created by Clare Jones on 19/03/2020.
//  Copyright © 2020 Clare Jones. All rights reserved.
//

import UIKit

class TaskListViewControllerTableViewController: UITableViewController {
    
    var taskArray:[TaskEntry]=[];

    override func viewDidLoad() {
        super.viewDidLoad()
        
        if let savedTasks = loadTasks(){
            taskArray = savedTasks;
        }

        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        self.navigationItem.leftBarButtonItem = self.editButtonItem
    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return taskArray.count;
    }

    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "taskCell", for: indexPath)

        // Configure the cell...
        cell.textLabel?.text = taskArray[indexPath.row].Title;

        return cell
    }
    

    /*
    // Override to support conditional editing of the table view.
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    */

    
    // Override to support editing the table view.
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            //delete row from the array
            taskArray.remove(at: indexPath.row);
            
            // Delete the row from the data source
            tableView.deleteRows(at: [indexPath], with: .fade)
            
            saveTasks();
        }
    }
    

    /*
    // Override to support rearranging the table view.
    override func tableView(_ tableView: UITableView, moveRowAt fromIndexPath: IndexPath, to: IndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    */

    
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        super.prepare(for: segue, sender: sender)
        
        switch (segue.identifier ?? ""){
        case "addTask":
            break;
        case "viewTask":
            //load ditails
            guard let taskViewContoller = segue.destination as? TaskViewController else{
                fatalError("unexpected destination");
            }
            guard let indexPath = tableView.indexPathForSelectedRow else{
                fatalError("The selected cell is not being displayed");
            }
            let selectedTask = taskArray[indexPath.row];
            taskViewContoller.task = selectedTask;
            
            break;
            default:
            fatalError("unexpected segue");
            break;
        }
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    
    
    @IBAction func unwindToTasks(sender:UIStoryboardSegue){
        //cast to TaskLisViewTableController
        if let sourceViewController = sender.source as? TaskViewController, let task = sourceViewController.task{
            if let selectedIndexPath = tableView.indexPathForSelectedRow{
                //update the exsisting task
                
                taskArray[selectedIndexPath.row] = task;
                tableView.reloadRows(at: [selectedIndexPath], with: .none);
                
            }else{
                let newIndexPath = IndexPath(row:taskArray.count, section:0);
                
                taskArray.append(task);
                    
                
                tableView.insertRows(at: [newIndexPath], with: .automatic);
            }
            saveTasks();
        
        }
    }
    
    //private methods
    
    private func saveTasks(){
        let isSucsessfulSave = NSKeyedArchiver.archiveRootObject(taskArray, toFile: TaskEntry.ArchiveURL.path)
        if !isSucsessfulSave{
            print("save unsuccessful");
        }
    }
    
    private func loadTasks() -> [TaskEntry]?{
        return NSKeyedUnarchiver.unarchiveObject(withFile: TaskEntry.ArchiveURL.path) as? [TaskEntry];
        
    }

}
